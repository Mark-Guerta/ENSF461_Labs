#ifndef __UTILS_H
#define __UTILS_H

#define TRUE 1
#define FALSE 0

void init_randomness();
int generate_random_int();
int generate_int_below_max(int max);

#endif
